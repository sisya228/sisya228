const NUM_FIRE_HELICOPTER = 15;
const NUM_NOFIRE_HELICOPTER = 17;
const urlGame = `<a href="${document.location.href}">Reset game</a>`;
const hrTop = 250;
var game = true;
var helicopterFire = 0;
var helicopterNoFire = 0;
var victory = false;
var cringe = false;
var touchScrin;

var displayElm;
var positionDisplay;
var touchElm;
var helElm;


const audio = {
  war: new Audio("/sounds/war.mp3"),
  fire: new Audio("/sounds/fire.mp3"),
  fireBonus: new Audio("/sounds/fire_bonus.mp3"),
  fly: new Audio("/sounds/fly.mp3"),
  helicopterRIP: new Audio("/sounds/helicopterRIP.mp3")
};
audio.war.volume = 0.3;
audio.fire.volume = 0.7;
audio.fly.volume = 0.5;
audio.fireBonus.volume = 0.9;


function testContact(arg) {
  // body...
  var block1 = displayElm.addElement();
  block1.id = 'b1';
  block1.className = 'myclass'
  var block2 = displayElm.addElement();
  block2.id = 'b2';
  block2.className = 'myclass'
  positionElement.getRelativeParentElement(block1);
  positionElement.getRelativeParentElement(block2);
}

function mouseEvn(elm) {
  //   elm.addEventListener("mousedown",
  //    function(evn){
  //   });

  //   elm.parentElement.addEventListener("mousemove",
  //   function(evn){
  //  });

  //  elm.addEventListener("mouseover",
  //   function(evn){
  //   });


  //  elm.addEventListener("mouseout",
  //  function(evn){
  //    console.log("mouse out");

  //  });

  //   elm.addEventListener("mouseup",
  //   function(evn){
  //     console.log("mouse up", evn.pageX);
  //  });

  var moveObj = new MovieElementForMouse(elm);
  moveObj.fixedElm = false;
  moveObj.moveFunc(touchFunctions.move.bind(touchFunctions), elm);
  moveObj.endFunc(touchFunctions.end);
  moveObj.setEvents();
}

function showFire(elm) {
  var style = elm.style;
  var movie = new MoveFromAToB(style.left, style.top, style.left, '5px', "5px", elm);
  movie.introFunction = fireFunction.intro;
  movie.moveFunction = fireFunction.move;
  movie.endFunction = fireFunction.end;
  movie.start(30);
}
const animationFire = {
  contactToHelicopter(elm, propertyNumAnimate, imgElm) {
    var style = elm.style;
    var styleImg = imgElm.style;
    var width = parseInt(style.width) + 10;
    var height = parseInt(style.height) + 10;
    style.width = width + "px";
    style.height = height + "px";
    style.borderRadius = (width / 2) + "px";
    style.filter = `opacity(${elm[propertyNumAnimate]*(100/animationFire.numbers.contactToHelicopter)}%)`;
    styleImg.width = width + "px";
    var numInfo = NUM_FIRE_HELICOPTER - helicopterFire;
    if (numInfo <= 5 && !elm.info) {
      var info = elm.addElement();
      info.className = "info1";
      info.innerHTML = numInfo;
      elm.info = true;
    }
    elm[propertyNumAnimate]--;
    return elm[propertyNumAnimate] >= 0;
  },
  numbers: {
    contactToHelicopter: 5,
  }
};
const fireFunction = {

  intro: function(obj) {
    playAudio(audio.fire);
  },
  move: function(obj, elm) {
    var contactFireHelicopter;
    var arrHelicopters = document.getElementsByClassName("helicopter");
    var elmHelicopter;
    for (let index = 0; index < arrHelicopters.length; index++) {
      elmHelicopter = arrHelicopters[index];
      contactFireHelicopter = contactObjects(obj.arg[5], elmHelicopter);
      if (contactFireHelicopter) {
        elmHelicopter.life = false;
        obj.stop();
        playAudio(audio.helicopterRIP);
        elm.numAnimation = animationFire.numbers.contactToHelicopter;
        var imgElm = elm.addElement("img");
        imgElm.src = "/img/fire.png";
        imgElm.className = "img-fire";
        elm.interval = setInterval(
          (elm, interval, numAnimation, imgElm) => {
            if (!animationFire.contactToHelicopter(elm, numAnimation, imgElm)) {
              clearInterval(elm[interval]);
              elm.remove();
            }
          },
          50,
          elm, "interval", "numAnimation", imgElm
        );
      }
    }


  },

  end: function(obj) {

  }

};

function showHelicopter(helicopterElm, paramsForClass) {
  //helicopterElm.style.left = leftA;
  //helicopterElm.style.top = topA;
  var movieHelicopter = new MoveFromAToB(...paramsForClass);
  //movieHelicopter.looping = true;
  movieHelicopter.introFunction = helicopterFunction.intro;
  movieHelicopter.moveFunction = helicopterFunction.move;
  movieHelicopter.endFunction = helicopterFunction.end;
  movieHelicopter.start(50);
}
var infoCringe = false;
const algorithmsFinalGame = {
  victory: (objMove, elmHelicopter) => {
    var style = elmHelicopter.style;
    elmHelicopter.numEndAnimation++;
    if (elmHelicopter.numEndAnimation < 30) {
      style.width = (parseInt(style.width) + 5) + "px";
      style.height = (parseInt(style.height) + 10) + "px";
      elmHelicopter.opacity -= 3;
      style.filter = `opacity(${elmHelicopter.opacity}%)`;
    } else {
      objMove.stop();
      displayElm.innerHTML = '<h1 class="victory">VICTORY !!!</h1>' + urlGame;
      game = false;
    }



    // elm.remove();
    // displayElm.innerHTML = "<h1>VICTORY!</H1>";
  },

  heroRIP: (objMove, elmHelicopter) => {
    objMove.stop();
    displayElm.style.color = "red";
    displayElm.innerHTML = "<h1>You RIP !!!</h1>" + urlGame;
    game = false;
  },

  cringe: (objMove, elmHelicopter) => {
    if (!infoCringe)
      displayElm.innerHTML = "<h1>CRINGE!</h1>" + urlGame;
    infoCringe = true;
    game = false;
  }
};
const algorithmsHelicopter = {
  life: function(objMove, elm) {
    elm.className = helElm.showClass ? "helicopter helicopter1" : "helicopter helicopter2";
    elm.showClass = !helElm.showClass;

  },
  info: function(objMove, elm) {
    var numInfo = NUM_NOFIRE_HELICOPTER - helicopterNoFire;
    if (numInfo <= 5 && numInfo > 0) {
      var info = displayElm.addElement("h3");
      info.className = "info2";
      info.innerHTML = numInfo;
      var style = info.style;
      style.left = elm.style.left;
      style.top = elm.style.top;
      setTimeout((elmInfo) => {
          info.remove();
        }, 1000,
        info)
    }
  },
  rip: function(objMove, elm) {
    elm.className = helElm.showClass ? "helicopterRIP helicopterRIP1" : "helicopterRIP helicopterRIP2";
    elm.showClass = !helElm.showClass;
    if (victory) {
      algorithmsFinalGame.victory(objMove, elm);
    }
    if (contactObjects(elm, touchElm) && !victory) {
      algorithmsFinalGame.heroRIP(objMove, elm);
    }
    touchFunctions.showBonusRect();
  }
};

const helicopterFunction = {
  newStart: true,
  intro: function(obj, elm) {
    // audio.fly = new Audio("/sounds/fly.mp3");
    var audioElm = audio.fly;
    playAudio(audioElm);
  },
  move: function(obj, elm) {
    if (elm.life) {
      algorithmsHelicopter.life(obj, elm);
    }
    if (!elm.life) {
      //algorithmsHelicopter''''''''''.rip(elm);
      obj.stop();
      helicopterFire++;
      victory = helicopterFire >= NUM_FIRE_HELICOPTER;
    }
  },

  end: function(obj, elm) {
    if (elm.life) {
      helicopterNoFire++;
      algorithmsHelicopter.info(obj, elm)
      elm.remove();
      cringe = helicopterNoFire >= NUM_NOFIRE_HELICOPTER;
      if (cringe && !victory) {
        algorithmsFinalGame.cringe(obj, elm);
      }
    }
    else {
      var moveHelicopter = new MoveFromAToB(
        elm.style.left, elm.style.top,
        elm.style.left, displayElm.style.height,
        5 + "px",
        elm
      );
      moveHelicopter.introFunction = (obj, elm) => {};
      moveHelicopter.moveFunction = (obj, elm) => {
        algorithmsHelicopter.rip(moveHelicopter, elm);
      }
      moveHelicopter.endFunction = (obj, elm) => {
        elm.remove();
      };
      moveHelicopter.start(50);
    }
  },
};

function play() {
  var interval = setInterval(
    function() {
      var helicopterElm = displayElm.addElement();
      helicopterElm.className = "helicopter";
      var positionHelicopter = positionElement.getRelativeParentElement(helicopterElm);
      helElm = helicopterElm;
      helicopterElm.life = true;
      helicopterElm.numEndAnimation = 0;
      helicopterElm.opacity = 100;
      var style = displayElm.style;
      var leftA = style.width;
      var topA = randomNumber(0, hrTop) + "px";
      var leftB = '0px';
      var topB = randomNumber(0, hrTop) + "px";
      var imgElm = helicopterElm.addElement("img");
      imgElm.src = "/img/helicopter.png";
      imgElm.className = "img-helicopter";
      var coordinates = [
      leftA, topA,
      leftB, topB,
      '5px',
      helicopterElm,
    ];
      showHelicopter(helicopterElm, coordinates);
    }, 3000
  );
}


var setMouseEvn;

function showTouch(elm) {
  touchElm = document.getElementById("block");
  touchElm.style.display = "block";
  var crdTouchElm = positionElement.getRelativeParentElement(touchElm);
  touchElm.addEventListener("touchstart", () => {
    touchScrin = true;
  })
  touchElm.addEventListener("mousedown", (evn) => {
    if (!touchScrin && !setMouseEvn) {
      mouseEvn(evn.currentTarget);
      setMouseEvn = true;
    }
  });
  //testMouseEvn(touchElm);
  var touchObj = new MovieElement(touchElm);
  touchObj.moveFunc((x, y, elm) => {
    return touchFunctions.move(x, y, elm);
  }, touchElm);
  touchObj.endFunc(touchFunctions.end);
  touchObj.setEvents();
}
const touchFunctions = {
  move(x, y, elm) {
    this.showBonus(x, y, elm);
    return y > hrTop;
  },
  end: (x, y) => {
    evnFire();
  },
  bonusZone: false,
  showBonusRect(x, y, elm) {
    this.bonusZone.className = "bonus";
    this.bonusZone.activity = true;
    var arrHelicopters = document.getElementsByClassName("helicopterRIP");
    class positions {
      constructor(elm) {
        this.x = parseInt(elm.style.left);
        this.y = parseInt(elm.style.top);
        this.width = parseInt(elm.style.width);
      }
    };
    var PositionHel1, positionHel2;
    if (arrHelicopters.length >= 2) {
      positionHel1 = new positions(arrHelicopters[0]);
      positionHel2 = new positions(arrHelicopters[1]);
      let width = positionHel1.x - positionHel2.x;
      width = width < 0 ? width * -1 : width;
      width = width + positionHel1.width;
      let height = positionHel1.y - positionHel2.y;
      height = height < 0 ? height * -1 : height;
      let x = Math.min(positionHel1.x, positionHel2.x);
      let y = Math.min(positionHel1.y, positionHel2.y);
      this.bonusZone.style.width = width + "px";
      this.bonusZone.style.height = height + "px";
      this.bonusZone.style.left = x + "px";
      this.bonusZone.style.top = y + "px";
      this.bonusZone.style.filter = `opacity(50%)`;
    } else {
      this.bonusZone.activity = false;
      this.bonusZone.style.filter = `opacity(0%)`;
    }
  },
  inBonus: false,
  interval: false,
  showBonus(x, y, elm) {
    if (this.bonusZone.activity) {
      let bonus = contactObjects(elm, this.bonusZone);
      if (bonus && !this.inBonus) {
        this.inBonus = true;
        this.interval = setInterval((elm) => {
          touchFunctions.fireBonus(elm)
        }, 100, elm);
        playAudio(audio.fireBonus);
      }
    }
  },
  leftFire: 0,
  fireBonus(touchElm) {
    var elmFire = displayElm.addElement();
    elmFire.className = "fire";
    var style = elmFire.style;
    style.left = this.leftFire + "px";
    style.top = hrTop + "px";
    showFire(elmFire);
    this.leftFire += 10;
    if (this.leftFire >= parseInt(displayElm.style.width)) {
      clearInterval(this.interval);
      this.inBonus = false;
      this.leftFire = 0;
    }
  }
};

evnFire = (x, y, elm) => {
  var fire = displayElm.addElement();
  fire.className = "fire";
  fire.style.left = touchElm.style.left;
  fire.style.top = touchElm.style.top;
  positionElement.getRelativeParentElement(fire);
  showFire(fire);
}

function playAudio(elm) {
  elm.autoplay = true;
  elm.currentTime = 0;
  return elm.play();
}

function imitationPlay(promise, element) {
  promise.then(
    () => {
      element.pause();
    },
    (msg) => {
      console.log("error anale: " + msg);
    }
  )
}
window.onload = () => {
  display.addDisplay();
  displayElm = document.getElementById("display");
  positionDisplay = positionElement.getRelativeDocument(displayElm);
  var playBtn = document.getElementById("play");
  playBtn.onclick = () => {
    playBtn.remove();
    play();
    showTouch();
    playAudio(audio.war);
    var prm = playAudio(audio.fireBonus);
    imitationPlay(prm, audio.fireBonus);
    /*
    .then(
      (arg) => audio.fireBonus.pause(),
      (arg) => console.log("error anale: "+arg)
      );
    */
  }
  var hr = displayElm.addElement("hr");
  touchFunctions.bonusZone = displayElm.addElement();
  //hr.style.position = "";
  hr.style.top = hrTop + "px";
  hr.style.left = '0px';
  /*
  warSound = displayElm.addElement("audio");
  warSound.autoplay = true;
  warSound.src = "/sounds/war.mp3"
  //warSound.pause();
  warSound.addEventListener("canplaythrough", () => {
    //warSound.play();
   //warSound.play();
  });
  */
  /*async function play(arg) {
     await warSound.play();
   }
  setTimeout(play, 5000);
  */
  /*
  fireSound = displayElm.addElement("audio");
  fireSound.autoplay = true;
  flySound = displayElm.addElement("audio");
   flySound.autoplay = true;
   helicopterRIPSound = displayElm.addElement("audio");
   helicopterRIPSound.autoplay = true;
   bonusSound = displayElm.addElement("audio");
   bonusSound.autoplay = true;
   */
  //testContact();
  /*
    var fireBtn = document.getElementById("btn");
    fireBtn.addEventListener("touchend", evnFire);
    */
};


function randomNumber(min, max) {
  var random = Math.random();
  return random * max;
}
